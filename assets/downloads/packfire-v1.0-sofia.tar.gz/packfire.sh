#!/bin/bash
# Packfire's executable setup shell script
php setup.php $@