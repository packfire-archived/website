<?php

/**
 * This is not the directory of the web application root.
 * Instead, the web application root folder is in the public folder relative to
 * this file.
 * 
 * Visitors to this file will be redirected to the public folder.
 */

header('Location: setup.php');
