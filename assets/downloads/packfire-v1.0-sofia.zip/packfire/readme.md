#packfire

This folder contains the framework classes and code that build the very way of life for your Packfire application. Take a look at all the packages in this folder and learn more about them through the `readme.md` files in each folder.